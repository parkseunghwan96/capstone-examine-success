package com.jbnu.comall.fragment;

import com.jbnu.comall.base.BaseFragment;

public class MyPageFragment extends BaseFragment {
}
